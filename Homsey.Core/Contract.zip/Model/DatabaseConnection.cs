﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homsey.Core.Entities
{
  internal class DatabaseConnection : DbContext
  {
    public DatabaseConnection() : base("name=DatabaseEntities") 
    { 
    }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      throw new UnintentionalCodeFirstException();
    }

    public DbSet<QuotationView> QuotationViews { get; set; }
    public DbSet<DataTranslation> DataTranslations { get; set; }
    public DbSet<Language> Languages { get; set; }
    public DbSet<MenuData> MenuDatas { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<PageContentView> PageContentViews { get; set; }
    public DbSet<Comment> Comments { get; set; }

    ////public static DatabaseEntities DatabaseContext
    ////{
    ////  get { return new DatabaseEntities(); }
    ////}
  }
}
