﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject;

namespace Homsey.Core.Entities
{
  internal class DataRepository : IDataRepository
  {
    private readonly IDataRepository _dataRepository;

    [Inject]
    public DataRepository(IDataRepository dataRepository)
    {
      _dataRepository = dataRepository;
    }

    public ICollection<IComment> GetAllComments()
    {
      throw new NotImplementedException();
    }

    public ICollection<IComment> GetCommentsByArticle(Guid languageID, Guid blogID)
    {
      using (var databaseContext = new DatabaseConnection())
      {
        var comments = from comment in databaseContext.Comments
                       where comment.LanguageID == languageID
                       where comment.BlogID == blogID
                       orderby comment.DateStamp descending
                       select comment;

        return comments.ToArray();
      }
    }

    public bool AddComment(string name, string email, string remark, Guid blogID, Guid languageID)
    {
      Comment comment = new Comment();
      comment.CommentID = Guid.NewGuid();
      comment.BlogID = blogID;
      comment.LanguageID = languageID;
      comment.Name = name;
      comment.Email = email;
      comment.Remark = remark;
      comment.DateStamp = DateTime.Now;

      using (var databaseContext = new DatabaseConnection())
      {
        databaseContext.Comments.Add(comment);
        databaseContext.SaveChanges();
        return true;
      }

      return false;
    }
  }
}
