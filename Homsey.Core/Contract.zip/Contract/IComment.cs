﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homsey.Core.Entities
{
  public interface IComment
  {
    Guid BlogID { get; }
    Guid LanguageID { get; }

    string Name { get; }
    string Remark { get; }
    string Email { get; }
  }
}
