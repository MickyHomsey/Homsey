﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homsey.Core.Entities
{
  public interface IDataRepository
  {
    ICollection<IComment> GetAllComments();
    bool AddComment(string name, string email, string remark, Guid blogID, Guid languageID);
    ICollection<IComment> GetCommentsByArticle(Guid languageID, Guid blogID);
  }
}
